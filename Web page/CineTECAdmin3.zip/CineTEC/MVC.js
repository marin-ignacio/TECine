
var main_module = angular.module('mainModule', ['ui.router']);

//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  main_module.config(function($stateProvider, $urlRouterProvider) {
    var states = [
      //Esto lo que hace es llamar a la pagina log_in 
      {
        name: 'log_in',
        //Esto indica que es la primera pagina
        url: '/',
        templateUrl: 'Pages/log_in_page.htm',
        controller: 'mainController'
      },{
        name: 'adminPage',
        url: '/AdminPage',
        templateUrl: 'Pages/AdminPage.htm',
        controller: 'adminController'
      },{//Pagina registro de peliculas
        name: 'movieRegister',
        url: '/MoviesRegister',
        templateUrl: 'Pages/MoviesRegister.htm',
        controller: 'MovieController'
      },{//Pagina registro de cines
        name: 'cinemaRegister',
        url: '/CinemaRegister',
        templateUrl: 'Pages/CinemaRegister.htm',
        controller: 'CinemaController'
      },{//Pagina registro de Cliente
        name: 'clientRegister',
        url: '/ClientRegister',
        templateUrl: 'Pages/ClientRegister.htm',
        controller: 'ClientController'
      },{//Pagina registro de Cartelera
        name: 'billboardRegister',
        url: '/BillboardRegister',
        templateUrl: 'Pages/BillboardRegister.htm',
        controller: 'BillboardController'
      },{//Pagina registro de Salas
        name: 'cinemaRoomRegister',
        url: '/CinemaRoomRegister',
        templateUrl: 'Pages/CinemaRoomRegister.htm',
        controller: 'CinemaRoomController'
      }
    ];
    states.forEach((state) => $stateProvider.state(state));
    $urlRouterProvider.otherwise('/');
  });
//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  
  //Este controlador es llamado por la pagina log_in_page y lo que hace es la logica de lo que va a pasar en esta pagina
  main_module.controller('mainController',function ($scope, $state){
    $scope.message = "Hello user, unfortunately we are in maintaining right now. Please come here later.";
    $scope.logintype = "administrador";
  
    $scope.goTo = function(page) {
      $state.go(page);
    };
  
    $scope.setLoginType = function(type) {
      $scope.logintype = type;
    };
  
    $scope.checkLogin = function(){
      
      var email = document.getElementById("email_input").value, pass = document.getElementById("password_input").value;
      if(email == "123" & pass == "123" ){
        $scope.goTo('adminPage');
      }else{
        alert("Email or password incorrect. Please, try again.");
      }
    };
  });


   //Este controlador es llamado por la pagina log_in_page y lo que hace es la logica de lo que va a pasar en esta pagina
   main_module.controller('adminController',function ($scope, $state){
  
    $scope.goTo = function(page) {
      $state.go(page);
    };

    //Me lleva al Registro de peliculas
    $scope.checkMovies = function(){
        $scope.goTo('movieRegister');
    };

    //Me lleva al Registro de Cine
    $scope.checkCinema = function(){
      $scope.goTo('cinemaRegister');
    };

    //Me lleva al Registro de cliente
    $scope.checkClient = function(){
      $scope.goTo('clientRegister');
    };

    //Me lleva al Registro de cartelera
    $scope.checkBillboard = function(){
      $scope.goTo('billboardRegister');
    };

    //Me lleva al Registro de sala
    $scope.checkCinemaRoom = function(){
      $scope.goTo('cinemaRoomRegister');
    };

    //Me lleva al Inicio de la pagina
    $scope.checkLogOut = function(){
      $scope.goTo('log_in');
    };



  });

    //Controlador de la pagina Registro de peliculas
  main_module.controller('MovieController',function ($scope, $state){
    $scope.message = "Hello user, unfortunately we are in maintaining right now. Please come here later.";
    $scope.logintype = "administrador";
  
    $scope.goTo = function(page) {
      $state.go(page);
    };

    $scope.checkBuscar = function(){
      alert("entra");
      
    };

    $scope.checkInsert = function(){
      $scope.goTo('adminPage');
    };
  });

  //Controlador de la pagina Registro de Cine
  main_module.controller('CinemaController',function ($scope, $state){
    $scope.message = "Hello user, unfortunately we are in maintaining right now. Please come here later.";
    $scope.logintype = "administrador";
  
    $scope.goTo = function(page) {
      $state.go(page);
    };
    
    $scope.checkInsert = function(){
      $scope.goTo('adminPage');
    };
  });

  //Controlador de la pagina Registro de cliente
  main_module.controller('ClientController',function ($scope, $state){
    $scope.message = "Hello user, unfortunately we are in maintaining right now. Please come here later.";
    $scope.logintype = "administrador";
  
    $scope.goTo = function(page) {
      $state.go(page);
    };
    
    $scope.checkInsert = function(){
      $scope.goTo('adminPage');
    };
  });

  //Controlador de la pagina Registro de cartelera
  main_module.controller('BillboardController',function ($scope, $state){
    $scope.message = "Hello user, unfortunately we are in maintaining right now. Please come here later.";
    $scope.logintype = "administrador";
  
    $scope.goTo = function(page) {
      $state.go(page);
    };
    
    $scope.checkInsert = function(){
      $scope.goTo('adminPage');
    };
  });

  //Controlador de la pagina Registro de sala
  main_module.controller('CinemaRoomController',function ($scope, $state){
    $scope.message = "Hello user, unfortunately we are in maintaining right now. Please come here later.";
    $scope.logintype = "administrador";
  
    $scope.goTo = function(page) {
      $state.go(page);
    };
    
    $scope.checkInsert = function(){
      $scope.goTo('adminPage');
    };
  });

  