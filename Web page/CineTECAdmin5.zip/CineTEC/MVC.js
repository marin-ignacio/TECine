
var main_module = angular.module('mainModule', ['ui.router']);

//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  main_module.config(function($stateProvider, $urlRouterProvider) {
    var states = [
      //Esto lo que hace es llamar a la pagina log_in 
      {
        name: 'log_in',
        //Esto indica que es la primera pagina
        url: '/',
        templateUrl: 'Pages/log_in_page.htm',
        controller: 'mainController'
      },{
        name: 'adminPage',
        url: '/AdminPage',
        templateUrl: 'Pages/AdminPage.htm',
        controller: 'adminController'
      },{//Pagina registro de peliculas
        name: 's',
        url: '/MoviesRegister',
        templateUrl: 'Pages/MoviesRegister.htm',
        controller: 'MovieController'
      },{//Pagina registro de cines
        name: 'cinemaRegister',
        url: '/CinemaRegister',
        templateUrl: 'Pages/CinemaRegister.htm',
        controller: 'CinemaController'
      },{//Pagina registro de Cliente
        name: 'clientRegister',
        url: '/ClientRegister',
        templateUrl: 'Pages/ClientRegister.htm',
        controller: 'ClientController'
      },{//Pagina registro de Cartelera
        name: 'ScreeningRegister',
        url: '/ScreeningRegister',
        templateUrl: 'Pages/ScreeningRegister.htm',
        controller: 'ScreeningController'
      },{//Pagina registro de Salas
        name: 'AuditoriumRegister',
        url: '/AuditoriumRegister',
        templateUrl: 'Pages/AuditoriumRegister.htm',
        controller: 'AuditoriumController'
      },{//Pagina Registro Pelicula extra Director
        name: 'MoviesRegisterDirector',
        url: '/MoviesRegisterDirector',
        templateUrl: 'Pages/MoviesRegisterDirector.html',
        controller: 'DirectorController'
      },{//Pagina Registro Pelicula extra Actor
        name: 'MoviesRegisterActor',
        url: '/MoviesRegisterActor',
        templateUrl: 'Pages/MoviesRegisterActor.html',
        controller: 'ActorController'
      }
      ,{//Pagina Registro Pelicula extra Genero
        name: 'MoviesRegisterGender',
        url: '/MoviesRegisterGender',
        templateUrl: 'Pages/MoviesRegisterGender.html',
        controller: 'GenderController'
      }
    ];
    states.forEach((state) => $stateProvider.state(state));
    $urlRouterProvider.otherwise('/');
  });
//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  
  //Este controlador es llamado por la pagina log_in_page y lo que hace es la logica de lo que va a pasar en esta pagina
  main_module.controller('mainController',function ($scope, $state){
    $scope.message = "Hello user, unfortunately we are in maintaining right now. Please come here later.";
    $scope.logintype = "administrador";
  
    $scope.goTo = function(page) {
      $state.go(page);
    };
  
    $scope.setLoginType = function(type) {
      $scope.logintype = type;
    };
  
    $scope.checkLogin = function(){
      
      var email = document.getElementById("email_input").value, pass = document.getElementById("password_input").value;
      if(email == "123" & pass == "123" ){
        $scope.goTo('adminPage');
      }else{
        alert("Email or password incorrect. Please, try again.");
      }
    };
  });


   //Este controlador es llamado por la pagina log_in_page y lo que hace es la logica de lo que va a pasar en esta pagina
   main_module.controller('adminController',function ($scope, $state){
  
    $scope.goTo = function(page) {
      $state.go(page);
    };

    //Me lleva al Registro de peliculas
    $scope.checkMovies = function(){
        $scope.goTo('s');
    };

    //Me lleva al Registro de Cine
    $scope.checkCinema = function(){
      $scope.goTo('cinemaRegister');
    };

    //Me lleva al Registro de cliente
    $scope.checkClient = function(){
      $scope.goTo('clientRegister');
    };

    //Me lleva al Registro de cartelera
    $scope.checkScreening = function(){
      $scope.goTo('ScreeningRegister');
    };

    //Me lleva al Registro de sala
    $scope.checkAuditorium = function(){
      $scope.goTo('AuditoriumRegister');
    };

    //Me lleva al Inicio de la pagina
    $scope.checkLogOut = function(){
      $scope.goTo('log_in');
    };



  });

    //Controlador de la pagina Registro de peliculas
  main_module.controller('MovieController',function ($scope, $state){

    $scope.Movie_template = {_Description:'', _Duration_min: '', _ID:'', _Original_title:'',_Title: ''};

    $scope.translate = {_Description:'Descripcion', _Duration_min: 'Duracion', _ID:'ID', _Original_title:'Titulo Original'
    , _Title: 'Titulo'};

    $scope.total_data = {
      'movies':[],
    };

    $(document).ready(function(){
      $.each($scope.total_data, function(key, v){
        $.ajax({
          type: 'GET',
          url: "http://192.168.100.28:8080/api/"+key,
          dataType: 'jsonp',
          success: function(data) {
            $.each(data, function(k, value){
              v.push(value);
              $scope.$apply();
            });
          },
          error: function(data){
          //alert("We can not establish a connection to the server right now. Please refresh page or try it later (:-/).");
          }
          });
        });
      });

    $scope.message = "Hello user, unfortunately we are in maintaining right now. Please come here later.";
    $scope.logintype = "administrador";
  
    $scope.goTo = function(page) {
      $state.go(page);
    };

    $scope.checkBuscar = function(){
      alert("entra");
      
    };
    $scope.checkBack = function(){
      $scope.goTo('adminPage');
    };

    $scope.checkInsert = function(){
      $scope.goTo('MoviesRegisterDirector');
    };
  });

  //Controlador de la pagina Registro de Cine
  main_module.controller('CinemaController',function ($scope, $state){

    $scope.Cinema_template = {_ID:'', _Name: '', _Location:''};

    $scope.translate = {_ID:'ID', _Name: 'Nombre del cine', _Location:'Ubicacion del cine'};

    $scope.total_data = {
      'cinemas':[],
    };

    $(document).ready(function(){
      $.each($scope.total_data, function(key, v){
        $.ajax({
          type: 'GET',
          url: "http://192.168.100.28:8080/api/"+key,
          dataType: 'jsonp',
          success: function(data) {
            $.each(data, function(k, value){
              v.push(value);
              $scope.$apply();
            });
          },
          error: function(data){
          //alert("We can not establish a connection to the server right now. Please refresh page or try it later (:-/).");
          }
          });
        });
      });

    $scope.message = "Hello user, unfortunately we are in maintaining right now. Please come here later.";
    $scope.logintype = "administrador";
  
    $scope.goTo = function(page) {
      $state.go(page);
    };
    
    $scope.checkInsert = function(){
      $scope.goTo('adminPage');
    };
  });

  //Controlador de la pagina Registro de cliente
  main_module.controller('ClientController',function ($scope, $state){

    $scope.Client_template = {Email:'', Fname: '', ID:'', Lname:'', Password_:'', Phone:'', Sname:''};

    $scope.translate = {Email:'Correo Electronico', Fname: 'Primer Nombre', ID: 'ID', Lname: 'Apellido', 
    Password_: 'Contrasena', Phone: 'Telefono', Sname: 'Segundo Nombre'};

    $scope.total_data = {
      'clients':[],
    };

    $(document).ready(function(){
      $.each($scope.total_data, function(key, v){
        $.ajax({
          type: 'GET',
          url: "http://192.168.100.28:8080/api/"+key,
          dataType: 'jsonp',
          success: function(data) {
            $.each(data, function(k, value){
              v.push(value);
              $scope.$apply();
            });
          },
          error: function(data){
          //alert("We can not establish a connection to the server right now. Please refresh page or try it later (:-/).");
          }
          });
        });
      });

    $scope.message = "Hello user, unfortunately we are in maintaining right now. Please come here later.";
    $scope.logintype = "administrador";
  
    $scope.goTo = function(page) {
      $state.go(page);
    };
    
    $scope.checkInsert = function(){
      $scope.goTo('adminPage');
    };
  });

  //Controlador de la pagina Registro de cartelera
  main_module.controller('ScreeningController',function ($scope, $state){

    $scope.Screening_template = {Email:'', Fname: '', ID:'', Lname:'', Password_:'', Phone:'', Sname:''};

    $scope.Movie_template = {_Description:'', _Duration_min: '', _ID:'', _Original_title:'',_Title: ''};

    $scope.translate = {_Description:'Descripcion', _Duration_min: 'Duracion', _ID:'ID', _Original_title:'Titulo Original'
    , _Title: 'Titulo'};
    
    $scope.Cinema_template = {_ID:'', _Name: '', _Location:''};

    $scope.translate = {_ID:'ID', _Name: 'Nombre del cine', _Location:'Ubicacion del cine'};

    $scope.auditoriums_template = {_ID:'', _Name: ''};

    $scope.translate = {_ID:'ID', _Name: 'Nombre de la Sala'};

    $scope.total_data = {
      'movies':[],
      'cinemas':[],
      'auditoriums':[],
    };

    $(document).ready(function(){
      $.each($scope.total_data, function(key, v){
        $.ajax({
          type: 'GET',
          url: "http://192.168.100.28:8080/api/"+key,
          dataType: 'jsonp',
          success: function(data) {
            $.each(data, function(k, value){
              v.push(value);
              $scope.$apply();
            });
          },
          error: function(data){
          //alert("We can not establish a connection to the server right now. Please refresh page or try it later (:-/).");
          }
          });
        });
      });

    $scope.message = "Hello user, unfortunately we are in maintaining right now. Please come here later.";
    $scope.logintype = "administrador";
  
    $scope.goTo = function(page) {
      $state.go(page);
    };
    
    $scope.checkInsert = function(){
      $scope.goTo('adminPage');
    };
  });

  //Controlador de la pagina Registro de sala
  main_module.controller('AuditoriumController',function ($scope, $state){

    $scope.Cinema_template = {_ID:'', _Name: '', _Location:''};

    $scope.translate = {_ID:'ID', _Name: 'Nombre del cine', _Location:'Ubicacion del cine'};

    $scope.auditoriums_template = {_ID:'', _Name: ''};

    $scope.translate = {_ID:'ID', _Name: 'Nombre de la Sala'};

    $scope.total_data = {
      'auditoriums':[],
      'cinemas':[],
    };

    $(document).ready(function(){
      $.each($scope.total_data, function(key, v){
        $.ajax({
          type: 'GET',
          url: "http://192.168.100.28:8080/api/"+key,
          dataType: 'jsonp',
          success: function(data) {
            $.each(data, function(k, value){
              v.push(value);
              $scope.$apply();
            });
          },
          error: function(data){
          //alert("We can not establish a connection to the server right now. Please refresh page or try it later (:-/).");
          }
          });
        });
      });

    $scope.message = "Hello user, unfortunately we are in maintaining right now. Please come here later.";
    $scope.logintype = "administrador";
  
    $scope.goTo = function(page) {
      $state.go(page);
    };
    
    $scope.checkInsert = function(){
      $scope.goTo('adminPage');
    };
  });

    //Controlador de la pagina Registro de Pelicula Director
    main_module.controller('DirectorController',function ($scope, $state){

    $scope.Movie_template = {_Description:'', _Duration_min: '', _ID:'', _Original_title:'',_Title: ''};

    $scope.translate = {_Description:'Descripcion', _Duration_min: 'Duracion', _ID:'ID', _Original_title:'Titulo Original'
    , _Title: 'Titulo'};

    $scope.Director_template = {_Fname:'', _ID: '', _Lname: ''};

    $scope.translate = {_Fname:'Nombre', _ID: 'ID', _Lname: 'Apellido'};

    $scope.total_data = {
      'directors':[],
      'movies':[],
    };

    $(document).ready(function(){
      $.each($scope.total_data, function(key, v){
        $.ajax({
          type: 'GET',
          url: "http://192.168.100.28:8080/api/"+key,
          dataType: 'jsonp',
          success: function(data) {
            $.each(data, function(k, value){
              v.push(value);
              $scope.$apply();
            });
          },
          error: function(data){
          //alert("We can not establish a connection to the server right now. Please refresh page or try it later (:-/).");
          }
          });
        });
      });

      $scope.message = "Hello user, unfortunately we are in maintaining right now. Please come here later.";
      $scope.logintype = "administrador";
    
      $scope.goTo = function(page) {
        $state.go(page);
      };
      
      $scope.checkInsert = function(){
        $scope.goTo('MoviesRegisterActor');
      };
    });

    //Controlador de la pagina Registro de Pelicula Actor
    main_module.controller('ActorController',function ($scope, $state){

      $scope.Movie_template = {_Description:'', _Duration_min: '', _ID:'', _Original_title:'',_Title: ''};

      $scope.translate = {_Description:'Descripcion', _Duration_min: 'Duracion', _ID:'ID', _Original_title:'Titulo Original'
      , _Title: 'Titulo'};

      $scope.actor_template = {_Fname:'', _ID: '', _Lname: ''};

      $scope.translate = {_Fname:'Nombre', _ID: 'ID', _Lname: 'Apellido'};

    $scope.total_data = {
      'actors':[],
      'movies':[],
    };

    $(document).ready(function(){
      $.each($scope.total_data, function(key, v){
        $.ajax({
          type: 'GET',
          url: "http://192.168.100.28:8080/api/"+key,
          dataType: 'jsonp',
          success: function(data) {
            $.each(data, function(k, value){
              v.push(value);
              $scope.$apply();
            });
          },
          error: function(data){
          //alert("We can not establish a connection to the server right now. Please refresh page or try it later (:-/).");
          }
          });
        });
      });

      $scope.message = "Hello user, unfortunately we are in maintaining right now. Please come here later.";
      $scope.logintype = "administrador";
    
      $scope.goTo = function(page) {
        $state.go(page);
      };
      
      $scope.checkInsert = function(){
        $scope.goTo('MoviesRegisterGender');
      };
    });

    //Controlador de la pagina Registro de Pelicula Genero
    main_module.controller('GenderController',function ($scope, $state){

      $scope.Movie_template = {_Description:'', _Duration_min: '', _ID:'', _Original_title:'',_Title: ''};

      $scope.translate = {_Description:'Descripcion', _Duration_min: 'Duracion', _ID:'ID', _Original_title:'Titulo Original'
      , _Title: 'Titulo'};

      $scope.gender_template = {_ID:'', _Name: ''};

      $scope.translate = {_ID:'ID', _Name: 'Nombre'};

    $scope.total_data = {
      'genders':[],
      'movies':[],
    };

    $(document).ready(function(){
      $.each($scope.total_data, function(key, v){
        $.ajax({
          type: 'GET',
          url: "http://192.168.100.28:8080/api/"+key,
          dataType: 'jsonp',
          success: function(data) {
            $.each(data, function(k, value){
              v.push(value);
              $scope.$apply();
            });
          },
          error: function(data){
          //alert("We can not establish a connection to the server right now. Please refresh page or try it later (:-/).");
          }
          });
        });
      });

      $scope.message = "Hello user, unfortunately we are in maintaining right now. Please come here later.";
      $scope.logintype = "administrador";
    
      $scope.goTo = function(page) {
        $state.go(page);
      };
      
      $scope.checkInsert = function(){
        $scope.goTo('adminPage');
      };
    });
  
  
  

  