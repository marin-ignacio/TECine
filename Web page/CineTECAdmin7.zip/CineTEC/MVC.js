
var main_module = angular.module('mainModule', ['ui.router']);

//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  main_module.config(function($stateProvider, $urlRouterProvider) {
    var states = [
      // What it does is call the page log_in
      {
        name: 'log_in',
        // This indicates that it is the first page
        url: '/',
        templateUrl: 'Pages/log_in_page.htm',
        controller: 'mainController'
      },{// Record option page
        name: 'adminPage',
        url: '/AdminPage',
        templateUrl: 'Pages/AdminPage.htm',
        controller: 'adminController'
      },{// Movie record page
        name: 'MoviesRegister',
        url: '/MoviesRegister',
        templateUrl: 'Pages/MoviesRegister.htm',
        controller: 'MovieController'
      },{// Registration page of cinemas
        name: 'cinemaRegister',
        url: '/CinemaRegister',
        templateUrl: 'Pages/CinemaRegister.htm',
        controller: 'CinemaController'
      },{// Client view page
        name: 'clientRegister',
        url: '/ClientRegister',
        templateUrl: 'Pages/ClientRegister.htm',
        controller: 'ClientController'
      },{// Billboard registration page
        name: 'ScreeningRegister',
        url: '/ScreeningRegister',
        templateUrl: 'Pages/ScreeningRegister.htm',
        controller: 'ScreeningController'
      },{// Registration page of Auditorium
        name: 'AuditoriumRegister',
        url: '/AuditoriumRegister',
        templateUrl: 'Pages/AuditoriumRegister.htm',
        controller: 'AuditoriumController'
      },{// Director Registration Page
        name: 'MoviesRegisterDirector',
        url: '/MoviesRegisterDirector',
        templateUrl: 'Pages/MoviesRegisterDirector.html',
        controller: 'DirectorController'
      },{// Actor Record Page
        name: 'MoviesRegisterActor',
        url: '/MoviesRegisterActor',
        templateUrl: 'Pages/MoviesRegisterActor.html',
        controller: 'ActorController'
      }
      ,{// Gender Registration Page
        name: 'MoviesRegisterGender',
        url: '/MoviesRegisterGender',
        templateUrl: 'Pages/MoviesRegisterGender.html',
        controller: 'GenderController'
      }
    ];
    states.forEach((state) => $stateProvider.state(state));
    $urlRouterProvider.otherwise('/');
  });

//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  
  // This controller is called by log_in_page.htm and what it does is the logic of what will happen on this page
  main_module.controller('mainController',function ($scope, $state){
  
    $scope.goTo = function(page) {
      $state.go(page);
    };
  
    $scope.setLoginType = function(type) {
      $scope.logintype = type;
    };
  
    $scope.checkLogin = function(){
      
      var email = document.getElementById("email_input").value, pass = document.getElementById("password_input").value;
      if(email == "123" & pass == "123" ){
        $scope.goTo('adminPage');
      }else{
        alert("Email or password incorrect. Please, try again.");
      }
    };
  });

//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------

   // This controller is called by AdminPage.htm and what it does is the logic of what will happen on this page
   main_module.controller('adminController',function ($scope, $state){
  
    $scope.goTo = function(page) {
      $state.go(page);
    };

    //Opens Movie Registry page (MoviesRegister.htm)
    $scope.checkMovies = function(){
        $scope.goTo('MoviesRegister');
    };

    //Opens Film Registry page (CinemaRegister.htm)
    $scope.checkCinema = function(){
      $scope.goTo('cinemaRegister');
    };

    //Opens Client's view page (ClientRegister.htm)
    $scope.checkClient = function(){
      $scope.goTo('clientRegister');
    };

    //Opens Billboard Registry page (ScreeningRegister.htm)
    $scope.checkScreening = function(){
      $scope.goTo('ScreeningRegister');
    };

    //Opens Registration page of Auditorium (AuditoriumRegister.htm)
    $scope.checkAuditorium = function(){
      $scope.goTo('AuditoriumRegister');
    };

    //Takes me to the start of the website (log_in_page.htm)
    $scope.checkLogOut = function(){
      $scope.goTo('log_in');
    };
  });

//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------  

  // Controller for the movie registration page
  main_module.controller('MovieController',function ($scope, $state){
    // Movie_template
    $scope.Movie_template = {_Description:'', _Duration_min: '', _ID:'', _Image:'', _Original_title:'',_Title: ''};
    // translate the data given by the json 
    $scope.translate = {_Description:'Descripcion', _Duration_min: 'Duracion', _ID:'ID', _Original_title:'Titulo Original'
    , _Title: 'Titulo'};
    // total_data: list that saves the data that will be used in the json
    $scope.total_data = {
      'movies':[],
    };
    //Function used to create the get of the table to the database
    $(document).ready(function(){
      $.each($scope.total_data, function(key, v){
        $.ajax({
          type: 'GET',
          url: "http://192.168.100.28:8080/api/"+key,
          dataType: 'jsonp',
          success: function(data) {
            $.each(data, function(k, value){
              v.push(value);
              $scope.$apply();
            });
          },
          error: function(data){
          //alert("We can not establish a connection to the server right now. Please refresh page or try it later (:-/).");
          }
          });
        });
      });
    
    //This method does a POST action into the service layer
    $scope.doPOST = function(URL,body){
      $http.post('http://192.168.100.28:8080/api/'+URL,JSON.stringify(body), 
        {headers: new Headers({ 'Content-Type': 'application/jsonp' })}).then(function(data,status,headers,config){
          alert("Your transaction was successfuly completed.")
        },function(data,status,headers,config){
          alert("There was an error with your transaction.")
        });
    }

  $scope.goTo = function(page) {
    $state.go(page);
  };
  
  $scope.theimage = function (){
    var filename = document.getElementById('file-id').value;
    document.getElementById('file-path').value = filename;
    alert(filename);
   }

   $scope.imagen64 = ""

   function getBase64(file) {
    var reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = function () {
      console.log(reader.result);
      $scope.imagen64 = reader.result;
    };
    reader.onerror = function (error) {
      console.log('Error: ', error);
    };
  }

  document.getElementById('Button_image_input').addEventListener('click', function() {
    var files = document.getElementById('assign_image_input').files;
    if (files.length > 0) {
      getBase64(files[0]);
    }
  });

  // Function that inserts a new cinema in the database
  $scope.checkInsert = function()
  { 
    //var imageData=$base64.encode(image);
    //input: list of the data that is going to be inserted in the database
    var input = $scope.Movie_template;

    //alert('imagen: ' + $scope.imagen64);

    //var base64Image = document.getElementById("assign_image_input").files[0].name;

    //var b64 = btoa(base64Image);

    //var data = base64Image.replace(/^data:image\/\w+;base64,/, "");

    //input['_Image'] = document.getElementById("assign_image_input").files[0].name;


    input['_Duration_min'] = document.getElementById("assign_duration_input").value;
    alert(" Duracion: "+ input["_Duration_min"]);
    //doPost('cinema',input): inserts into the table cinemas all the data saved on the input
    //$scope.doPOST('movies',input);
    $scope.Movie_template = {};

    $scope.goTo('MoviesRegisterDirector');

    
  };

    //Returns to the page AdminPage.htm
    $scope.checkGoBack = function(){
      $scope.goTo('adminPage');
    };
    //Opens the page MoviesRegisterDirector.html
    //$scope.checkInsert = function(){
      //$scope.goTo('MoviesRegisterDirector');
    //};
  });

//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  //Controler of the page CinemaRegister.htm
  main_module.controller('CinemaController',function ($scope, $state, $http){
    // Cinema_template
    $scope.Cinema_template = {};
    // Translate the data given by the json
    $scope.translate = {_ID:'ID', _Name: 'Nombre del cine', _Location:'Ubicacion del cine'};
    // total_data: list that saves the data that will be used in the json
    $scope.total_data = {
      'cinemas':[],
    };
    //Function used to create the get of the table to the database
    $(document).ready(function(){
      $.each($scope.total_data, function(key, v){
        $.ajax({
          type: 'GET',
          url: "http://192.168.100.28:8080/api/"+key,
          dataType: 'jsonp',
          success: function(data) {
            $.each(data, function(k, value){
              v.push(value);
              $scope.$apply();
            });
          },
          error: function(data){
          //alert("We can not establish a connection to the server right now. Please refresh page or try it later (:-/).");
          }
          });
        });
      });
      
      //This method does a POST action into the service layer
      $scope.doPOST = function(URL,body){
        $http.post('http://192.168.100.28:8080/api/'+URL,JSON.stringify(body), 
          {headers: new Headers({ 'Content-Type': 'application/jsonp' })}).then(function(data,status,headers,config){
            alert("Your transaction was successfuly completed.")
          },function(data,status,headers,config){
            alert("There was an error with your transaction.")
          });
      }

    $scope.goTo = function(page) {
      $state.go(page);
    };

    // Function that inserts a new cinema in the database
    $scope.checkInsert = function(){
      //input: list of the data that is going to be inserted in the database
      var input = $scope.Cinema_template;
      input['_Name'] = document.getElementById("assign_name_input").value;
      input['_Location'] = document.getElementById("assign_location_input").value;
      alert(" Nombre: "+input["_Name"] + ", Ubicacion: " + input["_Location"]);
      //doPost('cinema',input): inserts into the table cinemas all the data saved on the input
      $scope.doPOST('cinemas',input);
      $scope.Cinema_template = {};
    };
    //Returns to the page AdminPage.htm
    $scope.checkGoBack = function(){
      $scope.goTo('adminPage');
    };

  });

//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------  

  //Controler for the page ClientRegister.htm
  main_module.controller('ClientController',function ($scope, $state){
    // Client_template
    $scope.Client_template = {Email:'', Fname: '', ID:'', Lname:'', Password_:'', Phone:'', Sname:''};
    // Translate the data given by the json
    $scope.translate = {Email:'Correo Electronico', Fname: 'Primer Nombre', ID: 'ID', Lname: 'Apellido', 
    Password_: 'Contrasena', Phone: 'Telefono', Sname: 'Segundo Nombre'};
    // total_data: list that saves the data that will be used in the json
    $scope.total_data = {
      'clients':[],
    };
    //Function used to create the get of the table to the database
    $(document).ready(function(){
      $.each($scope.total_data, function(key, v){
        $.ajax({
          type: 'GET',
          url: "http://192.168.100.28:8080/api/"+key,
          dataType: 'jsonp',
          success: function(data) {
            $.each(data, function(k, value){
              v.push(value);
              $scope.$apply();
            });
          },
          error: function(data){
          //alert("We can not establish a connection to the server right now. Please refresh page or try it later (:-/).");
          }
          });
        });
      });

    $scope.goTo = function(page) {
      $state.go(page);
    };
    //Returns to the page AdminPage.htm
    $scope.checkGoBack = function(){
      $scope.goTo('adminPage');
    };

  });

//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  //Controlador de la pagina Registro de cartelera
  main_module.controller('ScreeningController',function ($scope, $state){
    // Screening_template
    $scope.Screening_template = {Email:'', Fname: '', ID:'', Lname:'', Password_:'', Phone:'', Sname:''};
    // Movie_template
    $scope.Movie_template = {_Description:'', _Duration_min: '', _ID:'', _Original_title:'',_Title: ''};
    // Translate the data given by the json
    $scope.translate = {_Description:'Descripcion', _Duration_min: 'Duracion', _ID:'ID', _Original_title:'Titulo Original'
    , _Title: 'Titulo'};
    // Cinema_template
    $scope.Cinema_template = {_ID:'', _Name: '', _Location:''};
    // Translate the data given by the json
    $scope.translate = {_ID:'ID', _Name: 'Nombre del cine', _Location:'Ubicacion del cine'};
    // Auditoriums_template
    $scope.auditoriums_template = {_ID:'', _Name: ''};
    // Translate the data given by the json
    $scope.translate = {_ID:'ID', _Name: 'Nombre de la Sala'};
    // total_data: list that saves the data that will be used in the json
    $scope.total_data = {
      'movies':[],
      'cinemas':[],
      'auditoriums':[],
    };
    //Function used to create the get of the table to the database
    $(document).ready(function(){
      $.each($scope.total_data, function(key, v){
        $.ajax({
          type: 'GET',
          url: "http://192.168.100.28:8080/api/"+key,
          dataType: 'jsonp',
          success: function(data) {
            $.each(data, function(k, value){
              v.push(value);
              $scope.$apply();
            });
          },
          error: function(data){
          //alert("We can not establish a connection to the server right now. Please refresh page or try it later (:-/).");
          }
          });
        });
      });

    $scope.goTo = function(page) {
      $state.go(page);
    };
    //Returns to the page AdminPage.htm
    $scope.checkInsert = function(){
      $scope.goTo('adminPage');
    };
  });

//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  //Controler for the page AuditoriumRegister.htm
  main_module.controller('AuditoriumController',function ($scope, $state, $http){
    // Cinema_template
    $scope.Cinema_template = {_ID:'', _Name: '', _Location:''};
    // Translate the data given by the json
    $scope.translate = {_ID:'ID', _Name: 'Nombre del cine', _Location:'Ubicacion del cine'};
    // auditoriums_template
    $scope.auditoriums_template = {_ID:'', _Name: ''};
    // Translate the data given by the json
    $scope.translate = {_ID:'ID', _Name: 'Nombre de la Sala'};
    // total_data: list that saves the data that will be used in the json
    $scope.total_data = {
      'auditoriums':[],
      'cinemas':[],
    }; 
    //Function used to create the get of the table to the database
    $(document).ready(function(){
      $.each($scope.total_data, function(key, v){
        $.ajax({
          type: 'GET',
          url: "http://192.168.100.28:8080/api/"+key,
          dataType: 'jsonp',
          success: function(data) {
            $.each(data, function(k, value){
              v.push(value);
              $scope.$apply();
            });
          },
          error: function(data){
          //alert("We can not establish a connection to the server right now. Please refresh page or try it later (:-/).");
          }
          });
        });
      });

    function loadData (){
        return $http.get(url);
    }

    //POST PARA ASIGNAR
    //http://192.168.100.28:8080/api/cinemas/auditoriums

   //This method does a POST action into the service layer
   $scope.doPOST = function(URL,body){
    $http.post('http://192.168.100.28:8080/api/'+URL,JSON.stringify(body), 
      {headers: new Headers({ 'Content-Type': 'application/jsonp' })}).then(function(data,status,headers,config){
        alert("Your transaction was successfuly completed.")
      },function(data,status,headers,config){
        alert("There was an error with your transaction.")
      });
  }

  $scope.goTo = function(page) {
    $state.go(page);
  };
  //Function that inserts a data in the database 
  $scope.checkInsert = function(){
    //input: list of the data that is going to be inserted in the database
    var input = {};
    input['_Name'] = document.getElementById("assign_Name_input").value;
    alert(" Nombre: "+ input["_Name"]);
    //doPost('auditoriums',input): inserts into the table auditoriums all the data saved on the input
    $scope.doPOST('auditoriums',input);
    var input = {};
    loadData();
  };
  //Function that inserts a data in the database 
  $scope.checkAssign = function(){
    //input: list of the data that is going to be inserted in the database
    var input = {};
    input['_Auditorium_ID'] = Number(document.getElementById("assign_auditoriums_select").value);
    input['_Cinema_ID'] = Number(document.getElementById("assign_cinema_select").value);
    alert(" IDauditorio: "+ input['_Auditorium_ID'] + " IDcinema: " + input['_Cinema_ID']);
    //doPost('auditoriums',input): inserts into the table auditoriums all the data saved on the input
    $scope.doPOST('cinemas/auditoriums',input);
    var input = {};
    loadData();
  };
    //Returns to the page AdminPage.htm
    $scope.checkGoBack = function(){
      $scope.goTo('adminPage');
    };
  });

//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    //Controler for the page MoviesRegisterDirector.html
    main_module.controller('DirectorController',function ($scope, $state, $http){
    // Directors_template  
    $scope.directors_template = {};
    // Directors_template  
    $scope.Movie_template = {_Description:'', _Duration_min: '', _ID:'', _Original_title:'',_Title: ''};
    // Translate the data given by the json
    $scope.translate = {_Description:'Descripcion', _Duration_min: 'Duracion', _ID:'ID', _Original_title:'Titulo Original'
    , _Title: 'Titulo'};
    // Translate the data given by the json
    $scope.translate = {_Fname:'Nombre', _ID: 'ID', _Lname: 'Apellido'};
    // total_data: list that saves the data that will be used in the json
    $scope.total_data = {
      'directors':[],
      'movies':[],
    };
    //Function used to create the get of the table to the database
    $(document).ready(function(){
      $.each($scope.total_data, function(key, v){
        $.ajax({
          type: 'GET',
          url: "http://192.168.100.28:8080/api/"+key,
          dataType: 'jsonp',
          success: function(data) {
            $.each(data, function(k, value){
              v.push(value);
              $scope.$apply();
            });
          },
          error: function(data){
          //alert("We can not establish a connection to the server right now. Please refresh page or try it later (:-/).");
          }
          });
        });
      });

      //POST PARA ASIGNAR
      //http://192.168.100.28:8080/api/movies/directors

      //This method does a POST action into the service layer
      $scope.doPOST = function(URL,body){
        $http.post('http://192.168.100.28:8080/api/'+URL,JSON.stringify(body), 
          {headers: new Headers({ 'Content-Type': 'application/jsonp' })}).then(function(data,status,headers,config){
            alert("Your transaction was successfuly completed.")
          },function(data,status,headers,config){
            alert("There was an error with your transaction.")
          });
      }
    
      $scope.goTo = function(page) {
        $state.go(page);
      };
      //Function that inserts a data in the database 
      $scope.checkInsert = function(){
        //input: list of the data that is going to be inserted in the database
        var input = {};
        input['_Fname'] = document.getElementById("assign_Fname_input").value;
        input['_Lname'] = document.getElementById("assign_LName_input").value;
        alert(" Nombre: "+ input["_Fname"] + ", Apellido: " + input["_Lname"]);
        //doPost('directors',input)
        $scope.doPOST('directors',input);
        var input = {};
        alert("PLEASE refresh the page");
      };

      //Function that inserts a data in the database 
      $scope.checkAssign = function(){
        //input: list of the data that is going to be inserted in the database
        var input = {};
        
        input['_Director_ID'] = Number(document.getElementById("assign_directors_select").value);
        input['_Movie_ID'] = Number(document.getElementById("assign_movies_select").value);

        alert(" IDDirector: "+ input['_Director_ID'] + " IDMovie: " + input['_Movie_ID']);
        //doPost('movies/directors)
        $scope.doPOST('movies/directors',input);
        var input = {};
      };


      //Opens the page MoviesRegisterActor.html
      $scope.checkGoNext = function(){
        $scope.goTo('MoviesRegisterActor');
      };

    });

//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    //Controler for the page MoviesRegisterActor.html
    main_module.controller('ActorController',function ($scope, $state, $http){
      // Movie_template 
      $scope.Movie_template = {_Description:'', _Duration_min: '', _ID:'', _Original_title:'',_Title: ''};
      // Translate the data given by the json
      $scope.translate = {_Description:'Descripcion', _Duration_min: 'Duracion', _ID:'ID', _Original_title:'Titulo Original'
      , _Title: 'Titulo'};
      // Actor_template 
      $scope.actor_template = {_Fname:'', _ID: '', _Lname: ''};
      // Translate the data given by the json
      $scope.translate = {_Fname:'Nombre', _ID: 'ID', _Lname: 'Apellido'};
      // total_data: list that saves the data that will be used in the json
      $scope.total_data = {
        'actors':[],
        'movies':[],
      };
      //POST PARA ASIGNAR
      //http://192.168.100.28:8080/api/movies/actors
      
      //Function used to create the get of the table to the database
      $(document).ready(function(){
        $.each($scope.total_data, function(key, v){
          $.ajax({
            type: 'GET',
            url: "http://192.168.100.28:8080/api/"+key,
            dataType: 'jsonp',
            success: function(data) {
            $.each(data, function(k, value){
                v.push(value);
                $scope.$apply();
              });
            },
          error: function(data){
          //alert("We can not establish a connection to the server right now. Please refresh page or try it later (:-/).");
          }
          });
        });
      });

     //This method does a POST action into the service layer
     $scope.doPOST = function(URL,body){
      $http.post('http://192.168.100.28:8080/api/'+URL,JSON.stringify(body), 
        {headers: new Headers({ 'Content-Type': 'application/jsonp' })}).then(function(data,status,headers,config){
          alert("Your transaction was successfuly completed.")
        },function(data,status,headers,config){
          alert("There was an error with your transaction.")
        });
    }
  
    $scope.goTo = function(page) {
      $state.go(page);
    };
    //Function that inserts a data in the database 
    $scope.checkInsert = function(){
      //input: list of the data that is going to be inserted in the database
      var input = {};
      input['_Fname'] = document.getElementById("assign_Fname_input").value;
      input['_Lname'] = document.getElementById("assign_Lname_input").value;
      alert(" Nombre: "+ input["_Fname"] + ", Apellido: " + input["_Lname"]);
      //doPost('actors',input): inserts into the table actors all the data saved on the input
      $scope.doPOST('actors',input);
      var input = {};
      alert("PLEASE refresh the page");
    };

    //Function that inserts a data in the database 
    $scope.checkAssign = function(){
      //input: list of the data that is going to be inserted in the database
      var input = {};
      
      input['_Actor_ID'] = Number(document.getElementById("assign_actors_select").value);
      input['_Movie_ID'] = Number(document.getElementById("assign_movies_select").value);

      alert(" IDActor: "+ input['_Actor_ID'] + " IDMovie: " + input['_Movie_ID']);

      $scope.doPOST('movies/actors',input);
      var input = {};
    };
      //Opens the page MoviesRegisterGender.html
      $scope.checkGoNext = function(){
        $scope.goTo('MoviesRegisterGender');
      };
    });

//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------    

    //Controler for the page MoviesRegisterGender.html'
    main_module.controller('GenderController',function ($scope, $state, $http){
      // Movie_template 
      $scope.Movie_template = {_Description:'', _Duration_min: '', _ID:'', _Original_title:'',_Title: ''};
      // Translate the data given by the json
      $scope.translate = {_Description:'Descripcion', _Duration_min: 'Duracion', _ID:'ID', _Original_title:'Titulo Original'
      , _Title: 'Titulo'};
      // Gender_template 
      $scope.gender_template = {_ID:'', _Name: ''};
      // Translate the data given by the json
      $scope.translate = {_ID:'ID', _Name: 'Nombre'};
      // total_data: list that saves the data that will be used in the json
      $scope.total_data = {
        'genders':[],
        'movies':[],
      };

      //POST PARA ASIGNAR
      //http://192.168.100.28:8080/api/movies/genders

      //Function used to create the get of the table to the database
    $(document).ready(function(){
      $.each($scope.total_data, function(key, v){
        $.ajax({
          type: 'GET',
          url: "http://192.168.100.28:8080/api/"+key,
          dataType: 'jsonp',
          success: function(data) {
            $.each(data, function(k, value){
              v.push(value);
              $scope.$apply();
            });
          },
          error: function(data){
          //alert("We can not establish a connection to the server right now. Please refresh page or try it later (:-/).");
          }
          });
        });
      });

      //This method does a POST action into the service layer
     $scope.doPOST = function(URL,body){
      $http.post('http://192.168.100.28:8080/api/'+URL,JSON.stringify(body), 
        {headers: new Headers({ 'Content-Type': 'application/jsonp' })}).then(function(data,status,headers,config){
          alert("Your transaction was successfuly completed.")
        },function(data,status,headers,config){
          alert("There was an error with your transaction.")
        });
    }
  
    $scope.goTo = function(page) {
      $state.go(page);
    };
    //Function that inserts a data in the database 
    $scope.checkInsert = function(){
      //input: list of the data that is going to be inserted in the database
      var input = {};
      input['_Name'] = document.getElementById("assign_Name_input").value;
      alert(" Nombre: "+ input["_Name"]);
      //doPost('genders',input): inserts into the table genders all the data saved on the input
      $scope.doPOST('genders',input);
      var input = {};
      alert("PLEASE refresh the page");
    };

    //Function that inserts a data in the database 
    $scope.checkAssign = function(){
      //input: list of the data that is going to be inserted in the database
      var input = {};
      
      input['_Gender_ID'] = Number(document.getElementById("assign_genders_select").value);
      input['_Movie_ID'] = Number(document.getElementById("assign_movies_select").value);

      alert(" IDGender: "+ input['_Gender_ID'] + " IDMovie: " + input['_Movie_ID']);

      $scope.doPOST('movies/genders',input);
      var input = {};
    };

      //Returns to the page AdminPage.htm
      $scope.checkGoNext = function(){
        $scope.goTo('adminPage');
      };
    });

//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------






















  